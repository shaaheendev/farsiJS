import fs from "fs";
import compiler from "./module/compiler.mjs";

const myCode = fs.readFileSync("./myCode.txt", "utf-8");

const compiledCode = compiler(myCode);

eval(compiledCode);

// fs.writeFileSync("./jsCode.txt", compiledCode);
